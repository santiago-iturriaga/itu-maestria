for fp_file in $(ls *.fp)
do
    echo "Procesando ${fp_file}"
    
    echo "set term png" > plot.dat
    echo "set output '${fp_file}.png'" >> plot.dat
    echo "plot '${fp_file}'" >> plot.dat
    
	gnuplot plot.dat
done




