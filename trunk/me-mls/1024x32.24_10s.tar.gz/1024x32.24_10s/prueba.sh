eog scenario.11.workload.B.u_i_hihi.fp.png &
eog scenario.16.workload.B.u_i_hilo.fp.png &
eog scenario.3.workload.B.u_i_lolo.fp.png &
eog scenario.14.workload.B.u_i_hilo.fp.png &
eog scenario.13.workload.A.u_i_hilo.fp.png &
eog scenario.16.workload.A.u_i_hilo.fp.png &
eog scenario.17.workload.A.u_i_hihi.fp.png &
eog scenario.0.workload.B.u_i_lohi.fp.png &
eog scenario.10.workload.B.u_i_hihi.fp.png &
eog scenario.11.workload.A.u_i_hihi.fp.png &
eog scenario.13.workload.B.u_i_lohi.fp.png &

