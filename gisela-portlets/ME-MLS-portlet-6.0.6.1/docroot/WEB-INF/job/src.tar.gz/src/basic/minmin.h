/*
 * MINMIN heuristic basic implementation.
 */

#include "../etc_matrix.h"
#include "../solution.h"

#ifndef MINMIN_H_
#define MINMIN_H_

void compute_minmin(struct solution *solution);

#endif
