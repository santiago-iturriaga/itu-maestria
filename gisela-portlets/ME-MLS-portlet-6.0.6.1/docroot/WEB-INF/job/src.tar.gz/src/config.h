#ifndef CONFIG_H_
#define CONFIG_H_

#define OBJECTIVES 2

//#define CPU_RAND
//#define CPU_DRAND48
#define CPU_MERSENNE_TWISTER

#define OUTPUT_SOLUTION 1
//#define DEBUG
//#define DEBUG_DEV
//#define TIMMING

#endif //CONFIG_H_
